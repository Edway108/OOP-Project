/**
 * 
 */
/**
 * 
 */
module Tetrix {
	requires java.desktop;
}